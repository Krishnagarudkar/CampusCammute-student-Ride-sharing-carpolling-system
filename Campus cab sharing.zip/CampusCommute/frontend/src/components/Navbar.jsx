import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function Navbar() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  const dashboardPath = user?.role === 'ADMIN'
    ? '/admin'
    : user?.role === 'DRIVER'
    ? '/driver'
    : '/student'

  return (
    <nav className="bg-brand-700 text-white px-6 py-4 flex items-center justify-between shadow-md">
      <Link to="/" className="text-xl font-bold tracking-tight">
        🚗 Campus Commute
      </Link>
      <div className="flex items-center gap-6 text-sm font-medium">
        {user ? (
          <>
            <Link to={dashboardPath} className="hover:text-brand-100">Dashboard</Link>
            {user.role === 'STUDENT' && <Link to="/search" className="hover:text-brand-100">Find a Ride</Link>}
            <span className="text-brand-100">Hi, {user.name} ({user.role})</span>
            <button
              onClick={handleLogout}
              className="bg-white text-brand-700 px-3 py-1.5 rounded-md hover:bg-brand-50 transition"
            >
              Logout
            </button>
          </>
        ) : (
          <>
            <Link to="/login" className="hover:text-brand-100">Login</Link>
            <Link to="/register" className="bg-white text-brand-700 px-3 py-1.5 rounded-md hover:bg-brand-50 transition">
              Get Started
            </Link>
          </>
        )}
      </div>
    </nav>
  )
}
