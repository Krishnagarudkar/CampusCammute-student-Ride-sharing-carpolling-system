import { useEffect, useState } from 'react'
import api from '../api/axios'
import { useAuth } from '../context/AuthContext'
import { Card, Badge } from '../components/UI'

const emptyRide = { pickup: '', destination: '', departureTime: '', availableSeats: 3, pricePerSeat: 50 }

export default function DriverDashboard() {
  const { user } = useAuth()
  const [rides, setRides] = useState([])
  const [bookings, setBookings] = useState([])
  const [form, setForm] = useState(emptyRide)
  const [showForm, setShowForm] = useState(false)
  const [error, setError] = useState('')

  const load = () => {
    api.get('/rides/my-rides').then((res) => setRides(res.data.data)).catch(() => {})
    api.get('/bookings/driver').then((res) => setBookings(res.data.data)).catch(() => {})
  }

  useEffect(load, [])

  const createRide = async (e) => {
    e.preventDefault()
    setError('')
    try {
      await api.post('/rides', {
        ...form,
        availableSeats: Number(form.availableSeats),
        pricePerSeat: Number(form.pricePerSeat),
      })
      setForm(emptyRide)
      setShowForm(false)
      load()
    } catch (err) {
      setError(err.response?.data?.message || 'Could not create ride.')
    }
  }

  const startRide = async (id) => { await api.post(`/rides/${id}/start`); load() }
  const endRide = async (id) => { await api.post(`/rides/${id}/end`); load() }
  const cancelRide = async (id) => { await api.delete(`/rides/${id}`); load() }
  const accept = async (id) => { await api.post(`/bookings/${id}/accept`); load() }
  const reject = async (id) => { await api.post(`/bookings/${id}/reject`); load() }

  return (
    <div className="max-w-5xl mx-auto px-6 py-10">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Welcome, {user?.name}</h1>
        <button
          onClick={() => setShowForm((s) => !s)}
          className="bg-brand-600 text-white px-4 py-2 rounded-md font-semibold hover:bg-brand-700 transition"
        >
          {showForm ? 'Cancel' : '+ Create Ride'}
        </button>
      </div>

      {showForm && (
        <Card className="mb-8">
          {error && <div className="bg-red-50 text-red-700 text-sm rounded-md p-3 mb-4">{error}</div>}
          <form onSubmit={createRide} className="grid grid-cols-2 gap-4">
            <input required placeholder="Pickup" value={form.pickup} onChange={(e) => setForm({ ...form, pickup: e.target.value })}
              className="border border-gray-300 rounded-md px-3 py-2" />
            <input required placeholder="Destination" value={form.destination} onChange={(e) => setForm({ ...form, destination: e.target.value })}
              className="border border-gray-300 rounded-md px-3 py-2" />
            <input required type="datetime-local" value={form.departureTime} onChange={(e) => setForm({ ...form, departureTime: e.target.value })}
              className="border border-gray-300 rounded-md px-3 py-2" />
            <input required type="number" min="1" placeholder="Available seats" value={form.availableSeats}
              onChange={(e) => setForm({ ...form, availableSeats: e.target.value })}
              className="border border-gray-300 rounded-md px-3 py-2" />
            <input required type="number" min="0" placeholder="Price per seat" value={form.pricePerSeat}
              onChange={(e) => setForm({ ...form, pricePerSeat: e.target.value })}
              className="border border-gray-300 rounded-md px-3 py-2 col-span-2" />
            <button type="submit" className="col-span-2 bg-brand-600 text-white py-2.5 rounded-md font-semibold hover:bg-brand-700 transition">
              Publish Ride
            </button>
          </form>
        </Card>
      )}

      <h2 className="text-lg font-semibold mb-3">Your Rides</h2>
      <div className="grid gap-4 mb-10">
        {rides.length === 0 && <Card className="text-center text-gray-500 py-8">No rides yet — create one above.</Card>}
        {rides.map((r) => (
          <Card key={r.id} className="flex items-center justify-between">
            <div>
              <p className="font-semibold">{r.pickup} → {r.destination}</p>
              <p className="text-sm text-gray-500">{new Date(r.departureTime).toLocaleString()} · {r.availableSeats} seats · ₹{r.pricePerSeat}/seat</p>
            </div>
            <div className="flex items-center gap-3">
              <Badge status={r.status} />
              {r.status === 'SCHEDULED' && (
                <>
                  <button onClick={() => startRide(r.id)} className="text-sm text-brand-600 font-medium hover:underline">Start</button>
                  <button onClick={() => cancelRide(r.id)} className="text-sm text-red-600 font-medium hover:underline">Cancel</button>
                </>
              )}
              {r.status === 'ONGOING' && (
                <button onClick={() => endRide(r.id)} className="text-sm text-brand-600 font-medium hover:underline">End Ride</button>
              )}
            </div>
          </Card>
        ))}
      </div>

      <h2 className="text-lg font-semibold mb-3">Booking Requests</h2>
      <div className="grid gap-4">
        {bookings.length === 0 && <Card className="text-center text-gray-500 py-8">No booking requests yet.</Card>}
        {bookings.map((b) => (
          <Card key={b.id} className="flex items-center justify-between">
            <div>
              <p className="font-semibold">{b.studentName} — Ride #{b.rideId}</p>
              <p className="text-sm text-gray-500">{b.seatsBooked} seat(s)</p>
            </div>
            <div className="flex items-center gap-3">
              <Badge status={b.status} />
              {b.status === 'PENDING' && (
                <>
                  <button onClick={() => accept(b.id)} className="text-sm text-green-600 font-medium hover:underline">Accept</button>
                  <button onClick={() => reject(b.id)} className="text-sm text-red-600 font-medium hover:underline">Reject</button>
                </>
              )}
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
