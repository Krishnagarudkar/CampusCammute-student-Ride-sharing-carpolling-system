import { useState } from 'react'
import api from '../api/axios'
import { Card } from '../components/UI'

export default function SearchRide() {
  const [pickup, setPickup] = useState('')
  const [destination, setDestination] = useState('')
  const [rides, setRides] = useState([])
  const [searched, setSearched] = useState(false)
  const [bookingRideId, setBookingRideId] = useState(null)
  const [message, setMessage] = useState('')

  const search = async (e) => {
    e.preventDefault()
    const { data } = await api.get('/rides/search', { params: { pickup, destination } })
    setRides(data.data)
    setSearched(true)
  }

  const bookRide = async (rideId) => {
    setMessage('')
    setBookingRideId(rideId)
    try {
      await api.post('/bookings', { rideId, seatsBooked: 1 })
      setMessage('Booking request sent! Check your dashboard for status.')
    } catch (err) {
      setMessage(err.response?.data?.message || 'Could not book this ride.')
    } finally {
      setBookingRideId(null)
    }
  }

  return (
    <div className="max-w-4xl mx-auto px-6 py-10">
      <h1 className="text-2xl font-bold mb-6">Find a Ride</h1>

      <form onSubmit={search} className="flex flex-wrap gap-3 mb-8">
        <input
          placeholder="Pickup location" value={pickup} onChange={(e) => setPickup(e.target.value)}
          className="flex-1 min-w-[180px] border border-gray-300 rounded-md px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-brand-500"
        />
        <input
          placeholder="Destination" value={destination} onChange={(e) => setDestination(e.target.value)}
          className="flex-1 min-w-[180px] border border-gray-300 rounded-md px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-brand-500"
        />
        <button type="submit" className="bg-brand-600 text-white px-6 py-2.5 rounded-md font-semibold hover:bg-brand-700 transition">
          Search
        </button>
      </form>

      {message && <div className="bg-brand-50 text-brand-700 text-sm rounded-md p-3 mb-6">{message}</div>}

      {searched && rides.length === 0 && (
        <Card className="text-center text-gray-500 py-10">No rides found for that route yet.</Card>
      )}

      <div className="grid gap-4">
        {rides.map((r) => (
          <Card key={r.id} className="flex items-center justify-between">
            <div>
              <p className="font-semibold">{r.pickup} → {r.destination}</p>
              <p className="text-sm text-gray-500">
                {new Date(r.departureTime).toLocaleString()} · Driver: {r.driverName} ({r.driverRating?.toFixed(1) ?? 'New'}★)
              </p>
              <p className="text-sm text-gray-500">{r.availableSeats} seats left · ₹{r.pricePerSeat}/seat</p>
            </div>
            <button
              onClick={() => bookRide(r.id)}
              disabled={bookingRideId === r.id}
              className="bg-brand-600 text-white px-4 py-2 rounded-md font-semibold hover:bg-brand-700 transition disabled:opacity-60"
            >
              {bookingRideId === r.id ? 'Booking...' : 'Book Seat'}
            </button>
          </Card>
        ))}
      </div>
    </div>
  )
}
