import { Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function Home() {
  const { user } = useAuth()

  return (
    <div className="max-w-5xl mx-auto px-6 py-20 text-center">
      <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-4">
        Smart Student Ride Sharing & Carpooling
      </h1>
      <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
        Campus Commute connects verified students with verified student drivers
        for safe, affordable, campus-to-anywhere rides.
      </p>
      {!user && (
        <div className="flex items-center justify-center gap-4">
          <Link to="/register" className="bg-brand-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-brand-700 transition">
            Get Started
          </Link>
          <Link to="/login" className="border border-brand-600 text-brand-600 px-6 py-3 rounded-lg font-semibold hover:bg-brand-50 transition">
            Login
          </Link>
        </div>
      )}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16 text-left">
        {[
          ['🎓', 'Verified Students Only', 'College email verification keeps the community trusted.'],
          ['🚘', 'Driver Verified', 'Admins check license & vehicle docs before drivers go live.'],
          ['⭐', 'Rated & Reviewed', 'Every ride ends with a rating, keeping quality high.'],
        ].map(([icon, title, desc]) => (
          <div key={title} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="text-3xl mb-3">{icon}</div>
            <h3 className="font-bold text-lg mb-1">{title}</h3>
            <p className="text-gray-600 text-sm">{desc}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
