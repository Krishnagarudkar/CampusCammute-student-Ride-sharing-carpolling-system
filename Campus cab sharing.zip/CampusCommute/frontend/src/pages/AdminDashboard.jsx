import { useEffect, useState } from 'react'
import api from '../api/axios'
import { Card, StatCard, Badge } from '../components/UI'

export default function AdminDashboard() {
  const [stats, setStats] = useState(null)
  const [users, setUsers] = useState([])
  const [complaints, setComplaints] = useState([])
  const [tab, setTab] = useState('overview')

  const load = () => {
    api.get('/admin/dashboard').then((res) => setStats(res.data.data)).catch(() => {})
    api.get('/admin/users').then((res) => setUsers(res.data.data)).catch(() => {})
    api.get('/admin/complaints').then((res) => setComplaints(res.data.data)).catch(() => {})
  }

  useEffect(load, [])

  const verifyStudent = async (id, approve) => { await api.post(`/admin/students/${id}/verify?approve=${approve}`); load() }
  const verifyDriver = async (id, approve) => { await api.post(`/admin/drivers/${id}/verify?approve=${approve}`); load() }
  const toggleBlock = async (u) => {
    await api.post(`/admin/users/${u.id}/${u.enabled ? 'block' : 'unblock'}`)
    load()
  }
  const resolveComplaint = async (id, resolved) => {
    await api.post(`/admin/complaints/${id}/resolve`, { resolved, remarks: resolved ? 'Reviewed and resolved.' : 'Reviewed and dismissed.' })
    load()
  }

  const pendingUsers = users.filter((u) => u.verificationStatus === 'PENDING')

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">
      <h1 className="text-2xl font-bold mb-6">Admin Dashboard</h1>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <StatCard label="Students" value={stats?.totalStudents ?? '—'} />
        <StatCard label="Drivers" value={stats?.totalDrivers ?? '—'} />
        <StatCard label="Pending Driver Verifications" value={stats?.pendingDriverVerifications ?? '—'} accent="text-amber-600" />
        <StatCard label="Total Rides" value={stats?.totalRides ?? '—'} />
        <StatCard label="Ongoing Rides" value={stats?.ongoingRides ?? '—'} accent="text-indigo-600" />
        <StatCard label="Completed Rides" value={stats?.completedRides ?? '—'} />
        <StatCard label="Open Complaints" value={stats?.openComplaints ?? '—'} accent="text-red-600" />
        <StatCard label="Total Revenue" value={`₹${(stats?.totalRevenue ?? 0).toFixed(2)}`} accent="text-green-600" />
      </div>

      <div className="flex gap-2 mb-6 bg-gray-100 rounded-lg p-1 w-fit">
        {['overview', 'users', 'complaints'].map((t) => (
          <button
            key={t} onClick={() => setTab(t)}
            className={`px-4 py-2 rounded-md text-sm font-semibold capitalize transition ${tab === t ? 'bg-white shadow text-brand-700' : 'text-gray-500'}`}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === 'overview' && (
        <>
          <h2 className="text-lg font-semibold mb-3">Pending Verifications</h2>
          <div className="grid gap-4">
            {pendingUsers.length === 0 && <Card className="text-center text-gray-500 py-8">Nothing pending — all caught up.</Card>}
            {pendingUsers.map((u) => (
              <Card key={u.id} className="flex items-center justify-between">
                <div>
                  <p className="font-semibold">{u.name} <span className="text-xs text-gray-400 font-normal">({u.role})</span></p>
                  <p className="text-sm text-gray-500">{u.email}</p>
                </div>
                <div className="flex items-center gap-3">
                  <Badge status={u.verificationStatus} />
                  <button
                    onClick={() => (u.role === 'DRIVER' ? verifyDriver(u.id, true) : verifyStudent(u.id, true))}
                    className="text-sm text-green-600 font-medium hover:underline"
                  >Approve</button>
                  <button
                    onClick={() => (u.role === 'DRIVER' ? verifyDriver(u.id, false) : verifyStudent(u.id, false))}
                    className="text-sm text-red-600 font-medium hover:underline"
                  >Reject</button>
                </div>
              </Card>
            ))}
          </div>
        </>
      )}

      {tab === 'users' && (
        <div className="grid gap-3">
          {users.map((u) => (
            <Card key={u.id} className="flex items-center justify-between">
              <div>
                <p className="font-semibold">{u.name} <span className="text-xs text-gray-400 font-normal">({u.role})</span></p>
                <p className="text-sm text-gray-500">{u.email}</p>
              </div>
              <div className="flex items-center gap-3">
                <Badge status={u.verificationStatus} />
                <button onClick={() => toggleBlock(u)} className={`text-sm font-medium hover:underline ${u.enabled ? 'text-red-600' : 'text-green-600'}`}>
                  {u.enabled ? 'Block' : 'Unblock'}
                </button>
              </div>
            </Card>
          ))}
        </div>
      )}

      {tab === 'complaints' && (
        <div className="grid gap-3">
          {complaints.length === 0 && <Card className="text-center text-gray-500 py-8">No complaints filed.</Card>}
          {complaints.map((c) => (
            <Card key={c.id}>
              <div className="flex items-center justify-between mb-2">
                <p className="font-semibold">{c.raisedBy?.name}</p>
                <Badge status={c.status} />
              </div>
              <p className="text-sm text-gray-600 mb-3">{c.description}</p>
              {c.status === 'OPEN' && (
                <div className="flex gap-3">
                  <button onClick={() => resolveComplaint(c.id, true)} className="text-sm text-green-600 font-medium hover:underline">Resolve</button>
                  <button onClick={() => resolveComplaint(c.id, false)} className="text-sm text-red-600 font-medium hover:underline">Dismiss</button>
                </div>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
