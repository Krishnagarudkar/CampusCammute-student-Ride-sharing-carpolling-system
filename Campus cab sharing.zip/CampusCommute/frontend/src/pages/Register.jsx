import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

const emptyStudent = { name: '', email: '', phoneNumber: '', password: '', collegeName: '', rollNumber: '', branch: '', yearOfStudy: '' }
const emptyDriver = { name: '', email: '', phoneNumber: '', password: '', licenseNo: '', licenseDocumentUrl: '' }

export default function Register() {
  const { registerStudent, registerDriver } = useAuth()
  const navigate = useNavigate()
  const [role, setRole] = useState('STUDENT')
  const [studentForm, setStudentForm] = useState(emptyStudent)
  const [driverForm, setDriverForm] = useState(emptyDriver)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      if (role === 'STUDENT') {
        const payload = { ...studentForm, yearOfStudy: studentForm.yearOfStudy ? Number(studentForm.yearOfStudy) : null }
        const session = await registerStudent(payload)
        navigate('/student')
      } else {
        const session = await registerDriver(driverForm)
        navigate('/driver')
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed.')
    } finally {
      setLoading(false)
    }
  }

  const inputClass = "mt-1 w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-brand-500"

  return (
    <div className="max-w-lg mx-auto mt-10 px-6 mb-16">
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8">
        <h1 className="text-2xl font-bold mb-2">Create your account</h1>
        <p className="text-gray-500 text-sm mb-6">Join as a passenger or register as a driver.</p>

        <div className="flex gap-2 mb-6 bg-gray-100 rounded-lg p-1">
          {['STUDENT', 'DRIVER'].map((r) => (
            <button
              key={r} type="button"
              onClick={() => setRole(r)}
              className={`flex-1 py-2 rounded-md text-sm font-semibold transition ${role === r ? 'bg-white shadow text-brand-700' : 'text-gray-500'}`}
            >
              {r === 'STUDENT' ? 'Student (Passenger)' : 'Driver'}
            </button>
          ))}
        </div>

        {error && <div className="bg-red-50 text-red-700 text-sm rounded-md p-3 mb-4">{error}</div>}

        <form onSubmit={handleSubmit} className="space-y-4">
          {role === 'STUDENT' ? (
            <>
              <Field label="Full Name" value={studentForm.name} onChange={(v) => setStudentForm({ ...studentForm, name: v })} inputClass={inputClass} />
              <Field label="College Email" type="email" value={studentForm.email} onChange={(v) => setStudentForm({ ...studentForm, email: v })} inputClass={inputClass} />
              <Field label="Phone Number" value={studentForm.phoneNumber} onChange={(v) => setStudentForm({ ...studentForm, phoneNumber: v })} inputClass={inputClass} />
              <Field label="Password" type="password" value={studentForm.password} onChange={(v) => setStudentForm({ ...studentForm, password: v })} inputClass={inputClass} />
              <div className="grid grid-cols-2 gap-4">
                <Field label="College Name" value={studentForm.collegeName} onChange={(v) => setStudentForm({ ...studentForm, collegeName: v })} inputClass={inputClass} required={false} />
                <Field label="Roll Number" value={studentForm.rollNumber} onChange={(v) => setStudentForm({ ...studentForm, rollNumber: v })} inputClass={inputClass} required={false} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <Field label="Branch" value={studentForm.branch} onChange={(v) => setStudentForm({ ...studentForm, branch: v })} inputClass={inputClass} required={false} />
                <Field label="Year of Study" type="number" value={studentForm.yearOfStudy} onChange={(v) => setStudentForm({ ...studentForm, yearOfStudy: v })} inputClass={inputClass} required={false} />
              </div>
            </>
          ) : (
            <>
              <Field label="Full Name" value={driverForm.name} onChange={(v) => setDriverForm({ ...driverForm, name: v })} inputClass={inputClass} />
              <Field label="Email" type="email" value={driverForm.email} onChange={(v) => setDriverForm({ ...driverForm, email: v })} inputClass={inputClass} />
              <Field label="Phone Number" value={driverForm.phoneNumber} onChange={(v) => setDriverForm({ ...driverForm, phoneNumber: v })} inputClass={inputClass} />
              <Field label="Password" type="password" value={driverForm.password} onChange={(v) => setDriverForm({ ...driverForm, password: v })} inputClass={inputClass} />
              <Field label="Driving License No." value={driverForm.licenseNo} onChange={(v) => setDriverForm({ ...driverForm, licenseNo: v })} inputClass={inputClass} />
              <Field label="License Document URL" value={driverForm.licenseDocumentUrl} onChange={(v) => setDriverForm({ ...driverForm, licenseDocumentUrl: v })} inputClass={inputClass} required={false} />
              <p className="text-xs text-gray-500">Your account will be reviewed by an admin before you can start creating rides.</p>
            </>
          )}

          <button
            type="submit" disabled={loading}
            className="w-full bg-brand-600 text-white font-semibold py-2.5 rounded-md hover:bg-brand-700 transition disabled:opacity-60"
          >
            {loading ? 'Creating account...' : 'Create Account'}
          </button>
        </form>

        <p className="text-sm text-gray-600 mt-5 text-center">
          Already have an account? <Link to="/login" className="text-brand-600 font-medium">Login</Link>
        </p>
      </div>
    </div>
  )
}

function Field({ label, value, onChange, inputClass, type = 'text', required = true }) {
  return (
    <div>
      <label className="text-sm font-medium text-gray-700">{label}</label>
      <input
        type={type} required={required} value={value ?? ''}
        onChange={(e) => onChange(e.target.value)}
        className={inputClass}
      />
    </div>
  )
}
