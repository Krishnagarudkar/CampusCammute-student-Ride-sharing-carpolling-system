import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import api from '../api/axios'
import { useAuth } from '../context/AuthContext'
import { Card, Badge } from '../components/UI'

export default function StudentDashboard() {
  const { user } = useAuth()
  const [bookings, setBookings] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    api.get('/bookings/student')
      .then((res) => setBookings(res.data.data))
      .catch(() => setError('Could not load your bookings.'))
      .finally(() => setLoading(false))
  }, [])

  const cancelBooking = async (id) => {
    await api.post(`/bookings/${id}/cancel`)
    setBookings((prev) => prev.map((b) => (b.id === id ? { ...b, status: 'CANCELLED' } : b)))
  }

  return (
    <div className="max-w-5xl mx-auto px-6 py-10">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Welcome, {user?.name}</h1>
        <Link to="/search" className="bg-brand-600 text-white px-4 py-2 rounded-md font-semibold hover:bg-brand-700 transition">
          + Find a Ride
        </Link>
      </div>

      <h2 className="text-lg font-semibold mb-3">Your Bookings</h2>
      {loading && <p className="text-gray-500">Loading...</p>}
      {error && <p className="text-red-600">{error}</p>}
      {!loading && bookings.length === 0 && (
        <Card className="text-center text-gray-500 py-10">
          No bookings yet. <Link to="/search" className="text-brand-600 font-medium">Search for a ride</Link> to get started.
        </Card>
      )}

      <div className="grid gap-4">
        {bookings.map((b) => (
          <Card key={b.id} className="flex items-center justify-between">
            <div>
              <p className="font-semibold">Ride #{b.rideId}</p>
              <p className="text-sm text-gray-500">{b.seatsBooked} seat(s) · booked {new Date(b.createdAt).toLocaleDateString()}</p>
            </div>
            <div className="flex items-center gap-3">
              <Badge status={b.status} />
              {(b.status === 'PENDING' || b.status === 'CONFIRMED') && (
                <button onClick={() => cancelBooking(b.id)} className="text-sm text-red-600 font-medium hover:underline">
                  Cancel
                </button>
              )}
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
