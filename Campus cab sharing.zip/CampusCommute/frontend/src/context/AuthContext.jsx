import { createContext, useContext, useState } from 'react'
import api from '../api/axios'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem('user')
    return stored ? JSON.parse(stored) : null
  })

  const login = async (email, password) => {
    const { data } = await api.post('/auth/login', { email, password })
    persistSession(data.data)
    return data.data
  }

  const registerStudent = async (payload) => {
    const { data } = await api.post('/auth/register/student', payload)
    persistSession(data.data)
    return data.data
  }

  const registerDriver = async (payload) => {
    const { data } = await api.post('/auth/register/driver', payload)
    persistSession(data.data)
    return data.data
  }

  const persistSession = (session) => {
    localStorage.setItem('accessToken', session.accessToken)
    localStorage.setItem('refreshToken', session.refreshToken)
    const userInfo = {
      userId: session.userId,
      name: session.name,
      email: session.email,
      role: session.role,
    }
    localStorage.setItem('user', JSON.stringify(userInfo))
    setUser(userInfo)
  }

  const logout = () => {
    localStorage.clear()
    setUser(null)
  }

  return (
    <AuthContext.Provider value={{ user, login, registerStudent, registerDriver, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  return useContext(AuthContext)
}
