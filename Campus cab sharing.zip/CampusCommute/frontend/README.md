# Campus Commute — Frontend (React · Vite · Tailwind CSS)

React SPA for the Campus Commute ride-sharing platform, talking to the
Spring Boot JWT backend in `campus-commute/`.

## Stack
React 18 · React Router · Axios · Tailwind CSS · Vite

## Setup

```bash
npm install
npm run dev
```

Runs on `http://localhost:5173`. The Vite dev server proxies `/api/*` to
`http://localhost:8080` (see `vite.config.js`) — start the backend first.

## Structure

```
src/
├── api/axios.js          Axios instance with JWT header + silent refresh
├── context/AuthContext.jsx  Login/register/logout, session in localStorage
├── components/           Navbar, ProtectedRoute, Card/StatCard/Badge
├── pages/
│   ├── Home.jsx
│   ├── Login.jsx / Register.jsx     (Student & Driver registration)
│   ├── StudentDashboard.jsx         Bookings list, cancel
│   ├── SearchRide.jsx               Search + book a ride
│   ├── DriverDashboard.jsx          Create/start/end rides, accept/reject bookings
│   └── AdminDashboard.jsx           Stats, verify students/drivers, block users, complaints
└── App.jsx                Routes, role-protected
```

## Notes
- Auth state and JWTs are kept in `localStorage` (`accessToken`, `refreshToken`, `user`).
- `ProtectedRoute` redirects unauthenticated users to `/login` and enforces
  role-based access per the use-case diagram (Student / Driver / Admin).
- Build for production: `npm run build` → outputs to `dist/`.
