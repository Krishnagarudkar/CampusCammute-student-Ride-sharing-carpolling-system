# Campus Commute — Backend (Java · Spring Boot · JWT · MySQL)

Smart Student Ride Sharing and Carpooling System — REST API backend implementing
the ER diagram (Student / Driver / Ride / Booking) and use-case diagram
(Student, Driver, Admin) from the project spec.

## Tech Stack

| Layer | Technology |
|---|---|
| Language | Java 17 |
| Framework | Spring Boot 3.2.5 |
| Security | Spring Security + JWT (jjwt 0.12) + BCrypt |
| Database | MySQL |
| ORM | Spring Data JPA / Hibernate |
| Build | Maven |

## Project Structure

```
src/main/java/com/campuscommute
├── config/           SecurityConfig (CORS, JWT filter chain, role rules)
├── security/          JwtUtil, JwtAuthFilter, CustomUserDetailsService
├── entity/             User, Student, Driver, Vehicle, Ride, Booking,
│                        Payment, Rating, Complaint, ChatMessage (+ enums)
├── repository/        Spring Data JPA repositories
├── dto/request/       Request payloads (validated with Jakarta Bean Validation)
├── dto/response/      Response payloads
├── service/           Interfaces + impl/ business logic
├── controller/        REST controllers
└── exception/          Custom exceptions + GlobalExceptionHandler
```

## Setup

1. **Create the database** (or let Hibernate auto-create it — see
   `createDatabaseIfNotExist=true` in `application.properties`):
   ```sql
   CREATE DATABASE campus_commute_db;
   ```
2. **Configure credentials** in `src/main/resources/application.properties`:
   ```properties
   spring.datasource.username=root
   spring.datasource.password=your_password
   app.jwt.secret=replace_with_a_long_random_secret
   ```
3. **Run:**
   ```bash
   mvn spring-boot:run
   ```
   API starts on `http://localhost:8080`.

## Authentication Flow

1. `POST /api/auth/register/student` or `/api/auth/register/driver` → returns JWT pair.
2. `POST /api/auth/login` → `{ accessToken, refreshToken }`.
3. Send `Authorization: Bearer <accessToken>` on every subsequent request.
4. `POST /api/auth/refresh` with `{ refreshToken }` when the access token expires.

Roles (`STUDENT`, `DRIVER`, `ADMIN`) are embedded in the JWT and enforced via
`hasRole(...)` rules in `SecurityConfig` — matching the three actors in the
use-case diagram.

> Admins are not self-registered via the API (no public "become an admin"
> endpoint, by design). Seed the first admin directly in the `users` table
> with a BCrypt-hashed password and `role = 'ADMIN'`, then manage further
> access from there.

## API Reference (high level)

| Area | Endpoint | Role |
|---|---|---|
| Auth | `POST /api/auth/register/student` | Public |
| Auth | `POST /api/auth/register/driver` | Public |
| Auth | `POST /api/auth/login` | Public |
| Auth | `POST /api/auth/refresh` | Public |
| Profile | `GET /api/profile/me` | Any authenticated |
| Vehicles | `POST/GET /api/driver/vehicles` | Driver |
| Rides | `POST /api/rides` (create) | Driver |
| Rides | `PUT /api/rides/{id}` (edit) | Driver |
| Rides | `DELETE /api/rides/{id}` (cancel) | Driver |
| Rides | `POST /api/rides/{id}/start` / `/end` | Driver |
| Rides | `GET /api/rides/search?pickup=&destination=` | Any authenticated |
| Rides | `GET /api/rides/{id}/details` | Any authenticated |
| Bookings | `POST /api/bookings` (book) | Student |
| Bookings | `POST /api/bookings/{id}/cancel` | Student |
| Bookings | `POST /api/bookings/{id}/accept` / `/reject` | Driver |
| Bookings | `GET /api/bookings/student` / `/driver` | Student / Driver |
| Payments | `POST /api/payments` | Student |
| Ratings | `POST /api/ratings`, `GET /api/ratings/driver/{id}` | Student / Public |
| Complaints | `POST /api/complaints`, `GET /api/complaints/me` | Any authenticated |
| Chat | `POST /api/chat`, `GET /api/chat/ride/{id}` | Any authenticated |
| Admin | `GET /api/admin/dashboard` | Admin |
| Admin | `GET /api/admin/users` | Admin |
| Admin | `POST /api/admin/students/{id}/verify?approve=true` | Admin |
| Admin | `POST /api/admin/drivers/{id}/verify?approve=true` | Admin |
| Admin | `POST /api/admin/users/{id}/block` / `/unblock` | Admin |
| Admin | `GET /api/admin/complaints`, `POST /api/admin/complaints/{id}/resolve` | Admin |

All responses are wrapped as:
```json
{ "success": true, "message": "...", "data": { ... }, "timestamp": "..." }
```

## Not Yet Wired (documented for the next iteration)

The project spec's future modules are intentionally left as extension points
rather than stubbed with fake logic:
- **Live GPS tracking / Google Maps API** — no location-streaming endpoint yet.
- **Real-time chat** — current `/api/chat` is REST history only; swap in
  Spring WebSocket/STOMP for live delivery.
- **Razorpay integration** — `PaymentServiceImpl` simulates a successful
  charge; replace with a real gateway call before production use.
- **AI ride matching/recommendation** — Module 6 & 14 (Python/ML) are a
  separate service, not part of this Java backend.
- **Firebase push notifications** — not implemented.
