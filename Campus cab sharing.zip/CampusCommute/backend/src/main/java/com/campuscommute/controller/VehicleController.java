package com.campuscommute.controller;

import com.campuscommute.dto.request.VehicleRequest;
import com.campuscommute.dto.response.ApiResponse;
import com.campuscommute.entity.Vehicle;
import com.campuscommute.service.VehicleService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/driver/vehicles")
@RequiredArgsConstructor
public class VehicleController {

    private final VehicleService vehicleService;

    @PostMapping
    public ResponseEntity<ApiResponse<Vehicle>> registerVehicle(Authentication auth, @Valid @RequestBody VehicleRequest request) {
        Vehicle vehicle = vehicleService.registerVehicle(auth.getName(), request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success("Vehicle registered", vehicle));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<Vehicle>>> myVehicles(Authentication auth) {
        return ResponseEntity.ok(ApiResponse.success("Your vehicles", vehicleService.getMyVehicles(auth.getName())));
    }
}
