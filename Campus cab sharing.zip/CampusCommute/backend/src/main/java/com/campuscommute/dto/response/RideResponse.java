package com.campuscommute.dto.response;

import com.campuscommute.entity.enums.RideStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RideResponse {
    private Long id;
    private Long driverId;
    private String driverName;
    private Double driverRating;
    private String vehicleModel;
    private String vehicleNumber;
    private String pickup;
    private String destination;
    private LocalDateTime departureTime;
    private Integer availableSeats;
    private Double pricePerSeat;
    private RideStatus status;
}
