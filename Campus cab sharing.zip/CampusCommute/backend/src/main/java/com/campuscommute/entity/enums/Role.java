package com.campuscommute.entity.enums;

public enum Role {
    STUDENT,
    DRIVER,
    ADMIN
}
