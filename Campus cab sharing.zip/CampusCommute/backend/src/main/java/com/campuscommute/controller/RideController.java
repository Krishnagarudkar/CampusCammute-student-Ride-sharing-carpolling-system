package com.campuscommute.controller;

import com.campuscommute.dto.request.RideRequest;
import com.campuscommute.dto.response.ApiResponse;
import com.campuscommute.dto.response.RideResponse;
import com.campuscommute.service.RideService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/rides")
@RequiredArgsConstructor
public class RideController {

    private final RideService rideService;

    @PostMapping
    public ResponseEntity<ApiResponse<RideResponse>> createRide(Authentication auth, @Valid @RequestBody RideRequest request) {
        RideResponse response = rideService.createRide(auth.getName(), request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success("Ride created", response));
    }

    @PutMapping("/{rideId}")
    public ResponseEntity<ApiResponse<RideResponse>> updateRide(Authentication auth, @PathVariable Long rideId, @Valid @RequestBody RideRequest request) {
        RideResponse response = rideService.updateRide(auth.getName(), rideId, request);
        return ResponseEntity.ok(ApiResponse.success("Ride updated", response));
    }

    @DeleteMapping("/{rideId}")
    public ResponseEntity<ApiResponse<Object>> cancelRide(Authentication auth, @PathVariable Long rideId) {
        rideService.cancelRide(auth.getName(), rideId);
        return ResponseEntity.ok(ApiResponse.success("Ride cancelled", null));
    }

    @GetMapping("/{rideId}/details")
    public ResponseEntity<ApiResponse<RideResponse>> getRideDetails(@PathVariable Long rideId) {
        return ResponseEntity.ok(ApiResponse.success("Ride details", rideService.getRideDetails(rideId)));
    }

    @GetMapping("/search")
    public ResponseEntity<ApiResponse<List<RideResponse>>> searchRides(
            @RequestParam(required = false) String pickup,
            @RequestParam(required = false) String destination) {
        return ResponseEntity.ok(ApiResponse.success("Search results", rideService.searchRides(pickup, destination)));
    }

    @GetMapping("/my-rides")
    public ResponseEntity<ApiResponse<List<RideResponse>>> myRides(Authentication auth) {
        return ResponseEntity.ok(ApiResponse.success("Your rides", rideService.getRidesByDriver(auth.getName())));
    }

    @PostMapping("/{rideId}/start")
    public ResponseEntity<ApiResponse<RideResponse>> startRide(Authentication auth, @PathVariable Long rideId) {
        return ResponseEntity.ok(ApiResponse.success("Ride started", rideService.startRide(auth.getName(), rideId)));
    }

    @PostMapping("/{rideId}/end")
    public ResponseEntity<ApiResponse<RideResponse>> endRide(Authentication auth, @PathVariable Long rideId) {
        return ResponseEntity.ok(ApiResponse.success("Ride completed", rideService.endRide(auth.getName(), rideId)));
    }
}
