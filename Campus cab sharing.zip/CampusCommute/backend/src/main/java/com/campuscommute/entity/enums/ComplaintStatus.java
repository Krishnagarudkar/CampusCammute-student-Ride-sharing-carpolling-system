package com.campuscommute.entity.enums;

public enum ComplaintStatus {
    OPEN,
    IN_PROGRESS,
    RESOLVED,
    REJECTED
}
