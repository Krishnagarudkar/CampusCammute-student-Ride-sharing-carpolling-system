package com.campuscommute.entity.enums;

public enum PaymentMethod {
    UPI,
    CARD,
    WALLET,
    CASH
}
