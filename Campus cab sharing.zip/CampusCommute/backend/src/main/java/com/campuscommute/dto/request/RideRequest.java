package com.campuscommute.dto.request;

import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class RideRequest {
    @NotBlank
    private String pickup;

    @NotBlank
    private String destination;

    @NotNull @Future
    private LocalDateTime departureTime;

    @NotNull @Positive
    private Integer availableSeats;

    @NotNull @Positive
    private Double pricePerSeat;

    private Long vehicleId;
}
