package com.campuscommute.service.impl;

import com.campuscommute.dto.request.ComplaintRequest;
import com.campuscommute.entity.Booking;
import com.campuscommute.entity.Complaint;
import com.campuscommute.entity.User;
import com.campuscommute.entity.enums.ComplaintStatus;
import com.campuscommute.exception.ResourceNotFoundException;
import com.campuscommute.repository.BookingRepository;
import com.campuscommute.repository.ComplaintRepository;
import com.campuscommute.repository.UserRepository;
import com.campuscommute.service.ComplaintService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ComplaintServiceImpl implements ComplaintService {

    private final ComplaintRepository complaintRepository;
    private final BookingRepository bookingRepository;
    private final UserRepository userRepository;

    @Override
    @Transactional
    public Complaint raiseComplaint(String userEmail, ComplaintRequest request) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Booking booking = null;
        if (request.getBookingId() != null) {
            booking = bookingRepository.findById(request.getBookingId())
                    .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));
        }

        Complaint complaint = Complaint.builder()
                .raisedBy(user)
                .booking(booking)
                .description(request.getDescription())
                .status(ComplaintStatus.OPEN)
                .build();

        return complaintRepository.save(complaint);
    }

    @Override
    public List<Complaint> getMyComplaints(String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        return complaintRepository.findByRaisedById(user.getId());
    }

    @Override
    public List<Complaint> getAllComplaints() {
        return complaintRepository.findAll();
    }

    @Override
    @Transactional
    public Complaint resolveComplaint(Long complaintId, String remarks, boolean resolved) {
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new ResourceNotFoundException("Complaint not found"));
        complaint.setStatus(resolved ? ComplaintStatus.RESOLVED : ComplaintStatus.REJECTED);
        complaint.setAdminRemarks(remarks);
        return complaintRepository.save(complaint);
    }
}
