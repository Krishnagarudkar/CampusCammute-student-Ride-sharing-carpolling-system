package com.campuscommute.service;

import com.campuscommute.dto.request.PaymentRequest;
import com.campuscommute.entity.Payment;

public interface PaymentService {
    Payment makePayment(String studentEmail, PaymentRequest request);
    Payment getPaymentForBooking(Long bookingId);
}
