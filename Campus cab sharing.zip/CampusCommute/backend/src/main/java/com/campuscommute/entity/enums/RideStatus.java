package com.campuscommute.entity.enums;

public enum RideStatus {
    SCHEDULED,
    ONGOING,
    COMPLETED,
    CANCELLED
}
