package com.campuscommute.service.impl;

import com.campuscommute.dto.request.ChatMessageRequest;
import com.campuscommute.entity.ChatMessage;
import com.campuscommute.entity.Ride;
import com.campuscommute.entity.User;
import com.campuscommute.exception.ResourceNotFoundException;
import com.campuscommute.repository.ChatMessageRepository;
import com.campuscommute.repository.RideRepository;
import com.campuscommute.repository.UserRepository;
import com.campuscommute.service.ChatService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * REST-based chat history (send + fetch). For real-time delivery, wire this
 * up to a Spring Boot WebSocket/STOMP broker as noted in the project spec —
 * the persistence layer here is broker-agnostic so that swap is additive.
 */
@Service
@RequiredArgsConstructor
public class ChatServiceImpl implements ChatService {

    private final ChatMessageRepository chatMessageRepository;
    private final RideRepository rideRepository;
    private final UserRepository userRepository;

    @Override
    @Transactional
    public ChatMessage sendMessage(String senderEmail, ChatMessageRequest request) {
        User sender = userRepository.findByEmail(senderEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        Ride ride = rideRepository.findById(request.getRideId())
                .orElseThrow(() -> new ResourceNotFoundException("Ride not found"));

        ChatMessage message = ChatMessage.builder()
                .ride(ride)
                .sender(sender)
                .message(request.getMessage())
                .build();

        return chatMessageRepository.save(message);
    }

    @Override
    public List<ChatMessage> getMessagesForRide(Long rideId) {
        return chatMessageRepository.findByRideIdOrderBySentAtAsc(rideId);
    }
}
