package com.campuscommute.entity.enums;

public enum VerificationStatus {
    PENDING,
    VERIFIED,
    REJECTED
}
