package com.campuscommute.service.impl;

import com.campuscommute.dto.request.RatingRequest;
import com.campuscommute.entity.Booking;
import com.campuscommute.entity.Driver;
import com.campuscommute.entity.Rating;
import com.campuscommute.entity.Student;
import com.campuscommute.entity.User;
import com.campuscommute.entity.enums.BookingStatus;
import com.campuscommute.exception.BadRequestException;
import com.campuscommute.exception.ResourceNotFoundException;
import com.campuscommute.exception.UnauthorizedException;
import com.campuscommute.repository.BookingRepository;
import com.campuscommute.repository.DriverRepository;
import com.campuscommute.repository.RatingRepository;
import com.campuscommute.repository.StudentRepository;
import com.campuscommute.repository.UserRepository;
import com.campuscommute.service.RatingService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class RatingServiceImpl implements RatingService {

    private final RatingRepository ratingRepository;
    private final BookingRepository bookingRepository;
    private final StudentRepository studentRepository;
    private final DriverRepository driverRepository;
    private final UserRepository userRepository;

    @Override
    @Transactional
    public Rating rateDriver(String studentEmail, RatingRequest request) {
        Booking booking = bookingRepository.findById(request.getBookingId())
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));

        User user = userRepository.findByEmail(studentEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        Student student = studentRepository.findById(user.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Student profile not found"));

        if (!booking.getStudent().getId().equals(student.getId())) {
            throw new UnauthorizedException("This booking does not belong to you");
        }
        if (booking.getStatus() != BookingStatus.COMPLETED) {
            throw new BadRequestException("You can only rate a driver after the ride is completed");
        }

        Driver driver = booking.getRide().getDriver();

        Rating rating = Rating.builder()
                .booking(booking)
                .student(student)
                .driver(driver)
                .stars(request.getStars())
                .comment(request.getComment())
                .build();
        rating = ratingRepository.save(rating);

        recalculateAverageRating(driver);

        return rating;
    }

    @Override
    public List<Rating> getRatingsForDriver(Long driverId) {
        return ratingRepository.findByDriverId(driverId);
    }

    private void recalculateAverageRating(Driver driver) {
        List<Rating> ratings = ratingRepository.findByDriverId(driver.getId());
        double avg = ratings.stream().mapToInt(Rating::getStars).average().orElse(0.0);
        driver.setAverageRating(Math.round(avg * 10.0) / 10.0);
        driverRepository.save(driver);
    }
}
