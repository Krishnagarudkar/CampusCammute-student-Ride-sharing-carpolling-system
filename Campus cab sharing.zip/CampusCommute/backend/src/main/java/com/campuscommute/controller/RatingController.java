package com.campuscommute.controller;

import com.campuscommute.dto.request.RatingRequest;
import com.campuscommute.dto.response.ApiResponse;
import com.campuscommute.entity.Rating;
import com.campuscommute.service.RatingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/ratings")
@RequiredArgsConstructor
public class RatingController {

    private final RatingService ratingService;

    @PostMapping
    public ResponseEntity<ApiResponse<Rating>> rateDriver(Authentication auth, @Valid @RequestBody RatingRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Rating submitted", ratingService.rateDriver(auth.getName(), request)));
    }

    @GetMapping("/driver/{driverId}")
    public ResponseEntity<ApiResponse<List<Rating>>> getDriverRatings(@PathVariable Long driverId) {
        return ResponseEntity.ok(ApiResponse.success("Driver ratings", ratingService.getRatingsForDriver(driverId)));
    }
}
