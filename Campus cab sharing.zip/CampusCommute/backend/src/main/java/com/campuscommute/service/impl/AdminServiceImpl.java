package com.campuscommute.service.impl;

import com.campuscommute.dto.response.DashboardStatsResponse;
import com.campuscommute.entity.User;
import com.campuscommute.entity.enums.ComplaintStatus;
import com.campuscommute.entity.enums.PaymentStatus;
import com.campuscommute.entity.enums.RideStatus;
import com.campuscommute.entity.enums.Role;
import com.campuscommute.entity.enums.VerificationStatus;
import com.campuscommute.exception.BadRequestException;
import com.campuscommute.exception.ResourceNotFoundException;
import com.campuscommute.repository.*;
import com.campuscommute.service.AdminService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AdminServiceImpl implements AdminService {

    private final UserRepository userRepository;
    private final RideRepository rideRepository;
    private final BookingRepository bookingRepository;
    private final ComplaintRepository complaintRepository;
    private final PaymentRepository paymentRepository;

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    @Transactional
    public User verifyStudent(Long studentId, boolean approve) {
        return updateVerification(studentId, Role.STUDENT, approve);
    }

    @Override
    @Transactional
    public User verifyDriver(Long driverId, boolean approve) {
        return updateVerification(driverId, Role.DRIVER, approve);
    }

    @Override
    @Transactional
    public User blockUser(Long userId) {
        User user = findUser(userId);
        user.setEnabled(false);
        return userRepository.save(user);
    }

    @Override
    @Transactional
    public User unblockUser(Long userId) {
        User user = findUser(userId);
        user.setEnabled(true);
        return userRepository.save(user);
    }

    @Override
    public DashboardStatsResponse getDashboardStats() {
        long totalStudents = userRepository.findAll().stream().filter(u -> u.getRole() == Role.STUDENT).count();
        long totalDrivers = userRepository.findAll().stream().filter(u -> u.getRole() == Role.DRIVER).count();
        long pendingDrivers = userRepository.findAll().stream()
                .filter(u -> u.getRole() == Role.DRIVER && u.getVerificationStatus() == VerificationStatus.PENDING)
                .count();

        long totalRides = rideRepository.count();
        long ongoingRides = rideRepository.findByStatus(RideStatus.ONGOING).size();
        long completedRides = rideRepository.findByStatus(RideStatus.COMPLETED).size();

        long totalBookings = bookingRepository.count();
        long openComplaints = complaintRepository.findAll().stream()
                .filter(c -> c.getStatus() == ComplaintStatus.OPEN).count();

        double revenue = paymentRepository.findAll().stream()
                .filter(p -> p.getStatus() == PaymentStatus.SUCCESS)
                .mapToDouble(p -> p.getAmount() == null ? 0 : p.getAmount())
                .sum();

        return DashboardStatsResponse.builder()
                .totalStudents(totalStudents)
                .totalDrivers(totalDrivers)
                .pendingDriverVerifications(pendingDrivers)
                .totalRides(totalRides)
                .ongoingRides(ongoingRides)
                .completedRides(completedRides)
                .totalBookings(totalBookings)
                .openComplaints(openComplaints)
                .totalRevenue(revenue)
                .build();
    }

    private User updateVerification(Long userId, Role expectedRole, boolean approve) {
        User user = findUser(userId);
        if (user.getRole() != expectedRole) {
            throw new BadRequestException("User is not a " + expectedRole.name().toLowerCase());
        }
        user.setVerificationStatus(approve ? VerificationStatus.VERIFIED : VerificationStatus.REJECTED);
        return userRepository.save(user);
    }

    private User findUser(Long userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
    }
}
