package com.campuscommute.dto.request;

import lombok.Data;

@Data
public class RideSearchRequest {
    private String pickup;
    private String destination;
}
