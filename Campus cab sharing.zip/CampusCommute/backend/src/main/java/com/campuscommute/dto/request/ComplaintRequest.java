package com.campuscommute.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class ComplaintRequest {
    private Long bookingId;

    @NotBlank
    private String description;
}
