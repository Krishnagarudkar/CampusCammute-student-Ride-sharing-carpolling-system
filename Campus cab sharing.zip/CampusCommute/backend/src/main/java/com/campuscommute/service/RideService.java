package com.campuscommute.service;

import com.campuscommute.dto.request.RideRequest;
import com.campuscommute.dto.response.RideResponse;

import java.util.List;

public interface RideService {
    RideResponse createRide(String driverEmail, RideRequest request);
    RideResponse updateRide(String driverEmail, Long rideId, RideRequest request);
    void cancelRide(String driverEmail, Long rideId);
    RideResponse getRideDetails(Long rideId);
    List<RideResponse> searchRides(String pickup, String destination);
    List<RideResponse> getRidesByDriver(String driverEmail);
    RideResponse startRide(String driverEmail, Long rideId);
    RideResponse endRide(String driverEmail, Long rideId);
}
