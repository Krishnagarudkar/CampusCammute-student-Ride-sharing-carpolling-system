package com.campuscommute.service;

import com.campuscommute.dto.request.RatingRequest;
import com.campuscommute.entity.Rating;

import java.util.List;

public interface RatingService {
    Rating rateDriver(String studentEmail, RatingRequest request);
    List<Rating> getRatingsForDriver(Long driverId);
}
