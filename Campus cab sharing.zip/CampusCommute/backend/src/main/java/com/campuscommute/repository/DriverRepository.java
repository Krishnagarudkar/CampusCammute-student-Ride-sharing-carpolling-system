package com.campuscommute.repository;

import com.campuscommute.entity.Driver;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface DriverRepository extends JpaRepository<Driver, Long> {
    Optional<Driver> findByLicenseNo(String licenseNo);
    boolean existsByLicenseNo(String licenseNo);
}
