package com.campuscommute.controller;

import com.campuscommute.dto.request.BookingRequest;
import com.campuscommute.dto.response.ApiResponse;
import com.campuscommute.dto.response.BookingResponse;
import com.campuscommute.service.BookingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
public class BookingController {

    private final BookingService bookingService;

    @PostMapping
    public ResponseEntity<ApiResponse<BookingResponse>> bookRide(Authentication auth, @Valid @RequestBody BookingRequest request) {
        BookingResponse response = bookingService.bookRide(auth.getName(), request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success("Ride booked, awaiting driver confirmation", response));
    }

    @PostMapping("/{bookingId}/cancel")
    public ResponseEntity<ApiResponse<Object>> cancelBooking(Authentication auth, @PathVariable Long bookingId) {
        bookingService.cancelBooking(auth.getName(), bookingId);
        return ResponseEntity.ok(ApiResponse.success("Booking cancelled", null));
    }

    @PostMapping("/{bookingId}/accept")
    public ResponseEntity<ApiResponse<BookingResponse>> acceptBooking(Authentication auth, @PathVariable Long bookingId) {
        return ResponseEntity.ok(ApiResponse.success("Booking accepted", bookingService.acceptBooking(auth.getName(), bookingId)));
    }

    @PostMapping("/{bookingId}/reject")
    public ResponseEntity<ApiResponse<BookingResponse>> rejectBooking(Authentication auth, @PathVariable Long bookingId) {
        return ResponseEntity.ok(ApiResponse.success("Booking rejected", bookingService.rejectBooking(auth.getName(), bookingId)));
    }

    @GetMapping("/student")
    public ResponseEntity<ApiResponse<List<BookingResponse>>> myBookingsAsStudent(Authentication auth) {
        return ResponseEntity.ok(ApiResponse.success("Your bookings", bookingService.getBookingsForStudent(auth.getName())));
    }

    @GetMapping("/driver")
    public ResponseEntity<ApiResponse<List<BookingResponse>>> myBookingsAsDriver(Authentication auth) {
        return ResponseEntity.ok(ApiResponse.success("Bookings on your rides", bookingService.getBookingsForDriver(auth.getName())));
    }
}
