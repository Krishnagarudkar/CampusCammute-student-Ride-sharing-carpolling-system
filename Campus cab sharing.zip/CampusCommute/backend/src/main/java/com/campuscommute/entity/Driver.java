package com.campuscommute.entity;

import jakarta.persistence.*;
import lombok.*;

/**
 * Driver profile — corresponds to the DRIVER entity in the ER diagram
 * (driver_id PK, license_no Unique).
 */
@Entity
@Table(name = "drivers", uniqueConstraints = @UniqueConstraint(columnNames = "license_no"))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Driver {

    @Id
    private Long id; // shares PK with User (id = User.id)

    @OneToOne
    @MapsId
    @JoinColumn(name = "id")
    private User user;

    @Column(name = "license_no", nullable = false, unique = true, length = 50)
    private String licenseNo;

    @Column(name = "license_document_url")
    private String licenseDocumentUrl;

    @Builder.Default
    @Column(name = "average_rating")
    private Double averageRating = 0.0;

    @Builder.Default
    @Column(name = "total_earnings")
    private Double totalEarnings = 0.0;
}
