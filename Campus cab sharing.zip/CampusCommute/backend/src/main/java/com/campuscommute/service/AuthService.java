package com.campuscommute.service;

import com.campuscommute.dto.request.LoginRequest;
import com.campuscommute.dto.request.RefreshTokenRequest;
import com.campuscommute.dto.request.RegisterDriverRequest;
import com.campuscommute.dto.request.RegisterStudentRequest;
import com.campuscommute.dto.response.AuthResponse;

public interface AuthService {
    AuthResponse registerStudent(RegisterStudentRequest request);
    AuthResponse registerDriver(RegisterDriverRequest request);
    AuthResponse login(LoginRequest request);
    AuthResponse refreshToken(RefreshTokenRequest request);
}
