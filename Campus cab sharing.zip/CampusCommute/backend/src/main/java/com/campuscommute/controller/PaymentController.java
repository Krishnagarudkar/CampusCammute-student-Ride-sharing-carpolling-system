package com.campuscommute.controller;

import com.campuscommute.dto.request.PaymentRequest;
import com.campuscommute.dto.response.ApiResponse;
import com.campuscommute.entity.Payment;
import com.campuscommute.service.PaymentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;

    @PostMapping
    public ResponseEntity<ApiResponse<Payment>> pay(Authentication auth, @Valid @RequestBody PaymentRequest request) {
        Payment payment = paymentService.makePayment(auth.getName(), request);
        return ResponseEntity.ok(ApiResponse.success("Payment successful", payment));
    }

    @GetMapping("/booking/{bookingId}")
    public ResponseEntity<ApiResponse<Payment>> getPayment(@PathVariable Long bookingId) {
        return ResponseEntity.ok(ApiResponse.success("Payment details", paymentService.getPaymentForBooking(bookingId)));
    }
}
