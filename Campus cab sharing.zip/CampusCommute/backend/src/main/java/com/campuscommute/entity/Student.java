package com.campuscommute.entity;

import jakarta.persistence.*;
import lombok.*;

/**
 * Student profile — corresponds to the STUDENT entity in the ER diagram
 * (student_id PK, name, phone_numbers). name/phone live on User; this table
 * holds student-specific attributes (college roll no., branch, year).
 */
@Entity
@Table(name = "students")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Student {

    @Id
    private Long id; // shares PK with User (id = User.id)

    @OneToOne
    @MapsId
    @JoinColumn(name = "id")
    private User user;

    @Column(name = "college_name", length = 150)
    private String collegeName;

    @Column(name = "roll_number", length = 50)
    private String rollNumber;

    @Column(length = 50)
    private String branch;

    @Column(name = "year_of_study")
    private Integer yearOfStudy;
}
