package com.campuscommute.service.impl;

import com.campuscommute.dto.request.BookingRequest;
import com.campuscommute.dto.response.BookingResponse;
import com.campuscommute.entity.Booking;
import com.campuscommute.entity.Ride;
import com.campuscommute.entity.Student;
import com.campuscommute.entity.User;
import com.campuscommute.entity.enums.BookingStatus;
import com.campuscommute.entity.enums.RideStatus;
import com.campuscommute.exception.BadRequestException;
import com.campuscommute.exception.ResourceNotFoundException;
import com.campuscommute.exception.UnauthorizedException;
import com.campuscommute.repository.BookingRepository;
import com.campuscommute.repository.RideRepository;
import com.campuscommute.repository.StudentRepository;
import com.campuscommute.repository.UserRepository;
import com.campuscommute.service.BookingService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;
    private final RideRepository rideRepository;
    private final StudentRepository studentRepository;
    private final UserRepository userRepository;

    @Override
    @Transactional
    public BookingResponse bookRide(String studentEmail, BookingRequest request) {
        Student student = getStudentByEmail(studentEmail);
        Ride ride = rideRepository.findById(request.getRideId())
                .orElseThrow(() -> new ResourceNotFoundException("Ride not found"));

        if (ride.getStatus() != RideStatus.SCHEDULED) {
            throw new BadRequestException("This ride is not open for booking");
        }
        if (ride.getAvailableSeats() < request.getSeatsBooked()) {
            throw new BadRequestException("Not enough seats available on this ride");
        }

        Booking booking = Booking.builder()
                .student(student)
                .ride(ride)
                .seatsBooked(request.getSeatsBooked())
                .status(BookingStatus.PENDING)
                .build();
        booking = bookingRepository.save(booking);

        // Tentatively hold seats; released back if the driver rejects/cancels.
        ride.setAvailableSeats(ride.getAvailableSeats() - request.getSeatsBooked());
        rideRepository.save(ride);

        return toResponse(booking);
    }

    @Override
    @Transactional
    public void cancelBooking(String studentEmail, Long bookingId) {
        Booking booking = findBooking(bookingId);
        Student student = getStudentByEmail(studentEmail);

        if (!booking.getStudent().getId().equals(student.getId())) {
            throw new UnauthorizedException("You do not own this booking");
        }
        if (booking.getStatus() == BookingStatus.CANCELLED || booking.getStatus() == BookingStatus.COMPLETED) {
            throw new BadRequestException("This booking cannot be cancelled");
        }

        releaseSeatsIfHeld(booking);
        booking.setStatus(BookingStatus.CANCELLED);
        bookingRepository.save(booking);
    }

    @Override
    @Transactional
    public BookingResponse acceptBooking(String driverEmail, Long bookingId) {
        Booking booking = getOwnedBookingForDriver(driverEmail, bookingId);
        if (booking.getStatus() != BookingStatus.PENDING) {
            throw new BadRequestException("Only pending bookings can be accepted");
        }
        booking.setStatus(BookingStatus.CONFIRMED);
        return toResponse(bookingRepository.save(booking));
    }

    @Override
    @Transactional
    public BookingResponse rejectBooking(String driverEmail, Long bookingId) {
        Booking booking = getOwnedBookingForDriver(driverEmail, bookingId);
        if (booking.getStatus() != BookingStatus.PENDING) {
            throw new BadRequestException("Only pending bookings can be rejected");
        }
        releaseSeatsIfHeld(booking);
        booking.setStatus(BookingStatus.REJECTED);
        return toResponse(bookingRepository.save(booking));
    }

    @Override
    public List<BookingResponse> getBookingsForStudent(String studentEmail) {
        Student student = getStudentByEmail(studentEmail);
        return bookingRepository.findByStudentId(student.getId()).stream().map(this::toResponse).toList();
    }

    @Override
    public List<BookingResponse> getBookingsForDriver(String driverEmail) {
        User user = userRepository.findByEmail(driverEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        return bookingRepository.findByRideDriverId(user.getId()).stream().map(this::toResponse).toList();
    }

    // ---- helpers ----

    private void releaseSeatsIfHeld(Booking booking) {
        Ride ride = booking.getRide();
        ride.setAvailableSeats(ride.getAvailableSeats() + booking.getSeatsBooked());
        rideRepository.save(ride);
    }

    private Student getStudentByEmail(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        return studentRepository.findById(user.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Student profile not found"));
    }

    private Booking findBooking(Long bookingId) {
        return bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));
    }

    private Booking getOwnedBookingForDriver(String driverEmail, Long bookingId) {
        Booking booking = findBooking(bookingId);
        User user = userRepository.findByEmail(driverEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        if (!booking.getRide().getDriver().getId().equals(user.getId())) {
            throw new UnauthorizedException("This booking does not belong to your ride");
        }
        return booking;
    }

    private BookingResponse toResponse(Booking booking) {
        return BookingResponse.builder()
                .id(booking.getId())
                .rideId(booking.getRide().getId())
                .studentId(booking.getStudent().getId())
                .studentName(booking.getStudent().getUser().getName())
                .seatsBooked(booking.getSeatsBooked())
                .status(booking.getStatus())
                .createdAt(booking.getCreatedAt())
                .build();
    }
}
