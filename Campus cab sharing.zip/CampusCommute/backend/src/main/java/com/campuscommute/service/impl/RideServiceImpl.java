package com.campuscommute.service.impl;

import com.campuscommute.dto.request.RideRequest;
import com.campuscommute.dto.response.RideResponse;
import com.campuscommute.entity.Driver;
import com.campuscommute.entity.Ride;
import com.campuscommute.entity.User;
import com.campuscommute.entity.Vehicle;
import com.campuscommute.entity.enums.RideStatus;
import com.campuscommute.exception.BadRequestException;
import com.campuscommute.exception.ResourceNotFoundException;
import com.campuscommute.exception.UnauthorizedException;
import com.campuscommute.repository.DriverRepository;
import com.campuscommute.repository.RideRepository;
import com.campuscommute.repository.UserRepository;
import com.campuscommute.repository.VehicleRepository;
import com.campuscommute.service.RideService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class RideServiceImpl implements RideService {

    private final RideRepository rideRepository;
    private final DriverRepository driverRepository;
    private final VehicleRepository vehicleRepository;
    private final UserRepository userRepository;

    @Override
    @Transactional
    public RideResponse createRide(String driverEmail, RideRequest request) {
        Driver driver = getDriverByEmail(driverEmail);

        Vehicle vehicle = null;
        if (request.getVehicleId() != null) {
            vehicle = vehicleRepository.findById(request.getVehicleId())
                    .orElseThrow(() -> new ResourceNotFoundException("Vehicle not found"));
            if (!vehicle.getDriver().getId().equals(driver.getId())) {
                throw new UnauthorizedException("This vehicle does not belong to you");
            }
        }

        Ride ride = Ride.builder()
                .driver(driver)
                .vehicle(vehicle)
                .pickup(request.getPickup())
                .destination(request.getDestination())
                .departureTime(request.getDepartureTime())
                .availableSeats(request.getAvailableSeats())
                .pricePerSeat(request.getPricePerSeat())
                .status(RideStatus.SCHEDULED)
                .build();

        return toResponse(rideRepository.save(ride));
    }

    @Override
    @Transactional
    public RideResponse updateRide(String driverEmail, Long rideId, RideRequest request) {
        Ride ride = getOwnedRide(driverEmail, rideId);

        if (ride.getStatus() != RideStatus.SCHEDULED) {
            throw new BadRequestException("Only scheduled rides can be edited");
        }

        ride.setPickup(request.getPickup());
        ride.setDestination(request.getDestination());
        ride.setDepartureTime(request.getDepartureTime());
        ride.setAvailableSeats(request.getAvailableSeats());
        ride.setPricePerSeat(request.getPricePerSeat());

        return toResponse(rideRepository.save(ride));
    }

    @Override
    @Transactional
    public void cancelRide(String driverEmail, Long rideId) {
        Ride ride = getOwnedRide(driverEmail, rideId);
        if (ride.getStatus() == RideStatus.COMPLETED) {
            throw new BadRequestException("Cannot cancel a completed ride");
        }
        ride.setStatus(RideStatus.CANCELLED);
        rideRepository.save(ride);
    }

    @Override
    public RideResponse getRideDetails(Long rideId) {
        return toResponse(findRide(rideId));
    }

    @Override
    public List<RideResponse> searchRides(String pickup, String destination) {
        return rideRepository.searchAvailableRides(
                        pickup == null ? "" : pickup,
                        destination == null ? "" : destination)
                .stream().map(this::toResponse).toList();
    }

    @Override
    public List<RideResponse> getRidesByDriver(String driverEmail) {
        Driver driver = getDriverByEmail(driverEmail);
        return rideRepository.findByDriverId(driver.getId()).stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional
    public RideResponse startRide(String driverEmail, Long rideId) {
        Ride ride = getOwnedRide(driverEmail, rideId);
        if (ride.getStatus() != RideStatus.SCHEDULED) {
            throw new BadRequestException("Only a scheduled ride can be started");
        }
        ride.setStatus(RideStatus.ONGOING);
        return toResponse(rideRepository.save(ride));
    }

    @Override
    @Transactional
    public RideResponse endRide(String driverEmail, Long rideId) {
        Ride ride = getOwnedRide(driverEmail, rideId);
        if (ride.getStatus() != RideStatus.ONGOING) {
            throw new BadRequestException("Only an ongoing ride can be ended");
        }
        ride.setStatus(RideStatus.COMPLETED);
        return toResponse(rideRepository.save(ride));
    }

    // ---- helpers ----

    private Driver getDriverByEmail(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        return driverRepository.findById(user.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Driver profile not found"));
    }

    private Ride findRide(Long rideId) {
        return rideRepository.findById(rideId)
                .orElseThrow(() -> new ResourceNotFoundException("Ride not found"));
    }

    private Ride getOwnedRide(String driverEmail, Long rideId) {
        Ride ride = findRide(rideId);
        Driver driver = getDriverByEmail(driverEmail);
        if (!ride.getDriver().getId().equals(driver.getId())) {
            throw new UnauthorizedException("You do not own this ride");
        }
        return ride;
    }

    private RideResponse toResponse(Ride ride) {
        return RideResponse.builder()
                .id(ride.getId())
                .driverId(ride.getDriver().getId())
                .driverName(ride.getDriver().getUser().getName())
                .driverRating(ride.getDriver().getAverageRating())
                .vehicleModel(ride.getVehicle() != null ? ride.getVehicle().getVehicleModel() : null)
                .vehicleNumber(ride.getVehicle() != null ? ride.getVehicle().getVehicleNumber() : null)
                .pickup(ride.getPickup())
                .destination(ride.getDestination())
                .departureTime(ride.getDepartureTime())
                .availableSeats(ride.getAvailableSeats())
                .pricePerSeat(ride.getPricePerSeat())
                .status(ride.getStatus())
                .build();
    }
}
