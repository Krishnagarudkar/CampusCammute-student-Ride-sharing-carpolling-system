package com.campuscommute.controller;

import com.campuscommute.dto.request.ComplaintRequest;
import com.campuscommute.dto.response.ApiResponse;
import com.campuscommute.entity.Complaint;
import com.campuscommute.service.ComplaintService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/complaints")
@RequiredArgsConstructor
public class ComplaintController {

    private final ComplaintService complaintService;

    @PostMapping
    public ResponseEntity<ApiResponse<Complaint>> raise(Authentication auth, @Valid @RequestBody ComplaintRequest request) {
        Complaint complaint = complaintService.raiseComplaint(auth.getName(), request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.success("Complaint submitted", complaint));
    }

    @GetMapping("/me")
    public ResponseEntity<ApiResponse<List<Complaint>>> myComplaints(Authentication auth) {
        return ResponseEntity.ok(ApiResponse.success("Your complaints", complaintService.getMyComplaints(auth.getName())));
    }
}
