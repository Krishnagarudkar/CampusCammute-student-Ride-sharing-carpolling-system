package com.campuscommute.dto.response;

import com.campuscommute.entity.enums.BookingStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BookingResponse {
    private Long id;
    private Long rideId;
    private Long studentId;
    private String studentName;
    private Integer seatsBooked;
    private BookingStatus status;
    private LocalDateTime createdAt;
}
