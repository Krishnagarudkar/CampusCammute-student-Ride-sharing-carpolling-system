package com.campuscommute.service.impl;

import com.campuscommute.dto.request.PaymentRequest;
import com.campuscommute.entity.Booking;
import com.campuscommute.entity.Payment;
import com.campuscommute.entity.Student;
import com.campuscommute.entity.User;
import com.campuscommute.entity.enums.BookingStatus;
import com.campuscommute.entity.enums.PaymentStatus;
import com.campuscommute.exception.BadRequestException;
import com.campuscommute.exception.ResourceNotFoundException;
import com.campuscommute.exception.UnauthorizedException;
import com.campuscommute.repository.BookingRepository;
import com.campuscommute.repository.PaymentRepository;
import com.campuscommute.repository.StudentRepository;
import com.campuscommute.repository.UserRepository;
import com.campuscommute.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository paymentRepository;
    private final BookingRepository bookingRepository;
    private final StudentRepository studentRepository;
    private final UserRepository userRepository;

    @Override
    @Transactional
    public Payment makePayment(String studentEmail, PaymentRequest request) {
        Booking booking = bookingRepository.findById(request.getBookingId())
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));

        User user = userRepository.findByEmail(studentEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        Student student = studentRepository.findById(user.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Student profile not found"));

        if (!booking.getStudent().getId().equals(student.getId())) {
            throw new UnauthorizedException("This booking does not belong to you");
        }
        if (booking.getStatus() != BookingStatus.CONFIRMED) {
            throw new BadRequestException("Payment can only be made for a confirmed booking");
        }

        double amount = booking.getSeatsBooked() * booking.getRide().getPricePerSeat();

        // NOTE: integrate a real gateway (Razorpay/Stripe) here; this simulates a
        // successful charge so the rest of the flow (rating, completion) can proceed.
        Payment payment = Payment.builder()
                .booking(booking)
                .amount(amount)
                .paymentMethod(request.getPaymentMethod())
                .status(PaymentStatus.SUCCESS)
                .transactionRef("TXN-" + UUID.randomUUID())
                .build();

        return paymentRepository.save(payment);
    }

    @Override
    public Payment getPaymentForBooking(Long bookingId) {
        return paymentRepository.findByBookingId(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("No payment found for this booking"));
    }
}
