package com.campuscommute.service;

import com.campuscommute.dto.request.VehicleRequest;
import com.campuscommute.entity.Vehicle;

import java.util.List;

public interface VehicleService {
    Vehicle registerVehicle(String driverEmail, VehicleRequest request);
    List<Vehicle> getMyVehicles(String driverEmail);
}
