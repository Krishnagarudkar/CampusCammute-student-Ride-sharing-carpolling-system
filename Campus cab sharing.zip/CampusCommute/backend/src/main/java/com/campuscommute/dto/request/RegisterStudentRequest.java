package com.campuscommute.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class RegisterStudentRequest {
    @NotBlank
    private String name;

    @NotBlank @Email
    private String email; // should be verified as a college email

    @NotBlank
    private String phoneNumber;

    @NotBlank
    private String password;

    private String collegeName;
    private String rollNumber;
    private String branch;
    private Integer yearOfStudy;
}
