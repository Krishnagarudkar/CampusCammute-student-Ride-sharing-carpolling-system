package com.campuscommute.repository;

import com.campuscommute.entity.Ride;
import com.campuscommute.entity.enums.RideStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface RideRepository extends JpaRepository<Ride, Long> {

    List<Ride> findByDriverId(Long driverId);

    List<Ride> findByStatus(RideStatus status);

    @Query("SELECT r FROM Ride r WHERE r.status = 'SCHEDULED' " +
           "AND LOWER(r.pickup) LIKE LOWER(CONCAT('%', :pickup, '%')) " +
           "AND LOWER(r.destination) LIKE LOWER(CONCAT('%', :destination, '%')) " +
           "AND r.availableSeats > 0")
    List<Ride> searchAvailableRides(@Param("pickup") String pickup,
                                     @Param("destination") String destination);
}
