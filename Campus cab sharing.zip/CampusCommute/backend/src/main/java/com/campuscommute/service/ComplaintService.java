package com.campuscommute.service;

import com.campuscommute.dto.request.ComplaintRequest;
import com.campuscommute.entity.Complaint;

import java.util.List;

public interface ComplaintService {
    Complaint raiseComplaint(String userEmail, ComplaintRequest request);
    List<Complaint> getMyComplaints(String userEmail);
    List<Complaint> getAllComplaints();
    Complaint resolveComplaint(Long complaintId, String remarks, boolean resolved);
}
