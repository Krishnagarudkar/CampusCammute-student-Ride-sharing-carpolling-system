package com.campuscommute.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DashboardStatsResponse {
    private long totalStudents;
    private long totalDrivers;
    private long pendingDriverVerifications;
    private long totalRides;
    private long ongoingRides;
    private long completedRides;
    private long totalBookings;
    private long openComplaints;
    private double totalRevenue;
}
