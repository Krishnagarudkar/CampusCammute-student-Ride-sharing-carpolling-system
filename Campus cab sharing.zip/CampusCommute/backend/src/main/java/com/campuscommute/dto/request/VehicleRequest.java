package com.campuscommute.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class VehicleRequest {
    @NotBlank
    private String vehicleNumber;
    private String vehicleModel;
    private String vehicleColor;
    @NotNull
    private Integer seatCapacity;
}
