package com.campuscommute.service;

import com.campuscommute.dto.request.BookingRequest;
import com.campuscommute.dto.response.BookingResponse;

import java.util.List;

public interface BookingService {
    BookingResponse bookRide(String studentEmail, BookingRequest request);
    void cancelBooking(String studentEmail, Long bookingId);
    BookingResponse acceptBooking(String driverEmail, Long bookingId);
    BookingResponse rejectBooking(String driverEmail, Long bookingId);
    List<BookingResponse> getBookingsForStudent(String studentEmail);
    List<BookingResponse> getBookingsForDriver(String driverEmail);
}
