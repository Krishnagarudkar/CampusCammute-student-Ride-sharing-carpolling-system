package com.campuscommute.service.impl;

import com.campuscommute.dto.request.LoginRequest;
import com.campuscommute.dto.request.RefreshTokenRequest;
import com.campuscommute.dto.request.RegisterDriverRequest;
import com.campuscommute.dto.request.RegisterStudentRequest;
import com.campuscommute.dto.response.AuthResponse;
import com.campuscommute.entity.Driver;
import com.campuscommute.entity.Student;
import com.campuscommute.entity.User;
import com.campuscommute.entity.enums.Role;
import com.campuscommute.entity.enums.VerificationStatus;
import com.campuscommute.exception.BadRequestException;
import com.campuscommute.exception.UnauthorizedException;
import com.campuscommute.repository.DriverRepository;
import com.campuscommute.repository.StudentRepository;
import com.campuscommute.repository.UserRepository;
import com.campuscommute.security.JwtUtil;
import com.campuscommute.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final StudentRepository studentRepository;
    private final DriverRepository driverRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final AuthenticationManager authenticationManager;

    @Override
    @Transactional
    public AuthResponse registerStudent(RegisterStudentRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new BadRequestException("An account already exists with this email");
        }

        User user = User.builder()
                .name(request.getName())
                .email(request.getEmail())
                .phoneNumber(request.getPhoneNumber())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(Role.STUDENT)
                .verificationStatus(VerificationStatus.PENDING)
                .build();
        user = userRepository.save(user);

        Student student = Student.builder()
                .id(user.getId())
                .user(user)
                .collegeName(request.getCollegeName())
                .rollNumber(request.getRollNumber())
                .branch(request.getBranch())
                .yearOfStudy(request.getYearOfStudy())
                .build();
        studentRepository.save(student);

        return buildAuthResponse(user);
    }

    @Override
    @Transactional
    public AuthResponse registerDriver(RegisterDriverRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new BadRequestException("An account already exists with this email");
        }
        if (driverRepository.existsByLicenseNo(request.getLicenseNo())) {
            throw new BadRequestException("This license number is already registered");
        }

        User user = User.builder()
                .name(request.getName())
                .email(request.getEmail())
                .phoneNumber(request.getPhoneNumber())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(Role.DRIVER)
                .verificationStatus(VerificationStatus.PENDING) // Admin must verify license before driving
                .build();
        user = userRepository.save(user);

        Driver driver = Driver.builder()
                .id(user.getId())
                .user(user)
                .licenseNo(request.getLicenseNo())
                .licenseDocumentUrl(request.getLicenseDocumentUrl())
                .build();
        driverRepository.save(driver);

        return buildAuthResponse(user);
    }

    @Override
    public AuthResponse login(LoginRequest request) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
        );

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new UnauthorizedException("Invalid email or password"));

        return buildAuthResponse(user);
    }

    @Override
    public AuthResponse refreshToken(RefreshTokenRequest request) {
        String email = jwtUtil.extractUsername(request.getRefreshToken());
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UnauthorizedException("Invalid refresh token"));

        if (!jwtUtil.isTokenValid(request.getRefreshToken(), user)) {
            throw new UnauthorizedException("Refresh token expired or invalid");
        }

        return buildAuthResponse(user);
    }

    private AuthResponse buildAuthResponse(User user) {
        String accessToken = jwtUtil.generateAccessToken(user);
        String refreshToken = jwtUtil.generateRefreshToken(user);

        return AuthResponse.builder()
                .accessToken(accessToken)
                .refreshToken(refreshToken)
                .tokenType("Bearer")
                .userId(user.getId())
                .name(user.getName())
                .email(user.getEmail())
                .role(user.getRole().name())
                .build();
    }
}
