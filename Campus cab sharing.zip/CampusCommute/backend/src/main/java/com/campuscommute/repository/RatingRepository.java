package com.campuscommute.repository;

import com.campuscommute.entity.Rating;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RatingRepository extends JpaRepository<Rating, Long> {
    List<Rating> findByDriverId(Long driverId);
}
