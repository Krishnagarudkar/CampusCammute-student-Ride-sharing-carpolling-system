package com.campuscommute.controller;

import com.campuscommute.dto.request.ChatMessageRequest;
import com.campuscommute.dto.response.ApiResponse;
import com.campuscommute.entity.ChatMessage;
import com.campuscommute.service.ChatService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/chat")
@RequiredArgsConstructor
public class ChatController {

    private final ChatService chatService;

    @PostMapping
    public ResponseEntity<ApiResponse<ChatMessage>> send(Authentication auth, @Valid @RequestBody ChatMessageRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Message sent", chatService.sendMessage(auth.getName(), request)));
    }

    @GetMapping("/ride/{rideId}")
    public ResponseEntity<ApiResponse<List<ChatMessage>>> history(@PathVariable Long rideId) {
        return ResponseEntity.ok(ApiResponse.success("Chat history", chatService.getMessagesForRide(rideId)));
    }
}
