package com.campuscommute.service.impl;

import com.campuscommute.dto.request.VehicleRequest;
import com.campuscommute.entity.Driver;
import com.campuscommute.entity.User;
import com.campuscommute.entity.Vehicle;
import com.campuscommute.exception.ResourceNotFoundException;
import com.campuscommute.repository.DriverRepository;
import com.campuscommute.repository.UserRepository;
import com.campuscommute.repository.VehicleRepository;
import com.campuscommute.service.VehicleService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class VehicleServiceImpl implements VehicleService {

    private final VehicleRepository vehicleRepository;
    private final DriverRepository driverRepository;
    private final UserRepository userRepository;

    @Override
    @Transactional
    public Vehicle registerVehicle(String driverEmail, VehicleRequest request) {
        User user = userRepository.findByEmail(driverEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        Driver driver = driverRepository.findById(user.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Driver profile not found"));

        Vehicle vehicle = Vehicle.builder()
                .driver(driver)
                .vehicleNumber(request.getVehicleNumber())
                .vehicleModel(request.getVehicleModel())
                .vehicleColor(request.getVehicleColor())
                .seatCapacity(request.getSeatCapacity())
                .build();

        return vehicleRepository.save(vehicle);
    }

    @Override
    public List<Vehicle> getMyVehicles(String driverEmail) {
        User user = userRepository.findByEmail(driverEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        return vehicleRepository.findByDriverId(user.getId());
    }
}
