package com.campuscommute.service;

import com.campuscommute.entity.User;
import com.campuscommute.dto.response.DashboardStatsResponse;

import java.util.List;

public interface AdminService {
    List<User> getAllUsers();
    User verifyStudent(Long studentId, boolean approve);
    User verifyDriver(Long driverId, boolean approve);
    User blockUser(Long userId);
    User unblockUser(Long userId);
    DashboardStatsResponse getDashboardStats();
}
