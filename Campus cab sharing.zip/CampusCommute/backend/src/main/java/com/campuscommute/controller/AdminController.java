package com.campuscommute.controller;

import com.campuscommute.dto.response.ApiResponse;
import com.campuscommute.dto.response.DashboardStatsResponse;
import com.campuscommute.entity.Complaint;
import com.campuscommute.entity.User;
import com.campuscommute.service.AdminService;
import com.campuscommute.service.ComplaintService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminController {

    private final AdminService adminService;
    private final ComplaintService complaintService;

    @GetMapping("/dashboard")
    public ResponseEntity<ApiResponse<DashboardStatsResponse>> dashboard() {
        return ResponseEntity.ok(ApiResponse.success("Dashboard stats", adminService.getDashboardStats()));
    }

    @GetMapping("/users")
    public ResponseEntity<ApiResponse<List<User>>> allUsers() {
        return ResponseEntity.ok(ApiResponse.success("All users", adminService.getAllUsers()));
    }

    @PostMapping("/students/{studentId}/verify")
    public ResponseEntity<ApiResponse<User>> verifyStudent(@PathVariable Long studentId, @RequestParam boolean approve) {
        return ResponseEntity.ok(ApiResponse.success("Student verification updated", adminService.verifyStudent(studentId, approve)));
    }

    @PostMapping("/drivers/{driverId}/verify")
    public ResponseEntity<ApiResponse<User>> verifyDriver(@PathVariable Long driverId, @RequestParam boolean approve) {
        return ResponseEntity.ok(ApiResponse.success("Driver verification updated", adminService.verifyDriver(driverId, approve)));
    }

    @PostMapping("/users/{userId}/block")
    public ResponseEntity<ApiResponse<User>> blockUser(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.success("User blocked", adminService.blockUser(userId)));
    }

    @PostMapping("/users/{userId}/unblock")
    public ResponseEntity<ApiResponse<User>> unblockUser(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.success("User unblocked", adminService.unblockUser(userId)));
    }

    @GetMapping("/complaints")
    public ResponseEntity<ApiResponse<List<Complaint>>> allComplaints() {
        return ResponseEntity.ok(ApiResponse.success("All complaints", complaintService.getAllComplaints()));
    }

    @PostMapping("/complaints/{complaintId}/resolve")
    public ResponseEntity<ApiResponse<Complaint>> resolveComplaint(@PathVariable Long complaintId, @RequestBody Map<String, Object> body) {
        String remarks = (String) body.getOrDefault("remarks", "");
        boolean resolved = (boolean) body.getOrDefault("resolved", true);
        return ResponseEntity.ok(ApiResponse.success("Complaint updated", complaintService.resolveComplaint(complaintId, remarks, resolved)));
    }
}
