package com.campuscommute.service;

import com.campuscommute.dto.request.ChatMessageRequest;
import com.campuscommute.entity.ChatMessage;

import java.util.List;

public interface ChatService {
    ChatMessage sendMessage(String senderEmail, ChatMessageRequest request);
    List<ChatMessage> getMessagesForRide(Long rideId);
}
