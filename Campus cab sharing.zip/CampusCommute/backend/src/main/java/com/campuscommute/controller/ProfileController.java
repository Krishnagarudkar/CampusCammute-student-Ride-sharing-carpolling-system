package com.campuscommute.controller;

import com.campuscommute.dto.response.ApiResponse;
import com.campuscommute.entity.User;
import com.campuscommute.repository.UserRepository;
import com.campuscommute.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

/**
 * Shared "Manage Profile" endpoints — available to any authenticated role
 * (Student, Driver, Admin), matching the use-case diagram.
 */
@RestController
@RequestMapping("/api/profile")
@RequiredArgsConstructor
public class ProfileController {

    private final UserRepository userRepository;

    @GetMapping("/me")
    public ResponseEntity<ApiResponse<User>> me(Authentication auth) {
        User user = userRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        return ResponseEntity.ok(ApiResponse.success("Profile", user));
    }
}
