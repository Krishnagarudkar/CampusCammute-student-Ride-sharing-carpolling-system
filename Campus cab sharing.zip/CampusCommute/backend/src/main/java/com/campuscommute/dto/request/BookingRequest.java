package com.campuscommute.dto.request;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

@Data
public class BookingRequest {
    @NotNull
    private Long rideId;

    @NotNull @Positive
    private Integer seatsBooked;
}
