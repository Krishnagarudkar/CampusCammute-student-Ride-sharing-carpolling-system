# Campus Commute — Smart Student Ride Sharing and Carpooling System

Full-stack implementation of the ER diagram (Student, Driver, Ride, Booking)
and use-case diagram (Student, Driver, Admin) from the project spec.

```
CampusCommute/
├── backend/     Java 17 · Spring Boot 3 · Spring Security + JWT · MySQL · Maven
└── frontend/    React 18 · Vite · Tailwind CSS · Axios
```

## Quick Start

**1. Backend**
```bash
cd backend
# edit src/main/resources/application.properties with your MySQL credentials
mvn spring-boot:run
```
Runs on `http://localhost:8080`. Full API reference in `backend/README.md`.

**2. Frontend**
```bash
cd frontend
npm install
npm run dev
```
Runs on `http://localhost:5173` and proxies `/api` calls to the backend.

## What's Implemented

- **Auth**: JWT (access + refresh), BCrypt password hashing, role-based
  access control (`STUDENT` / `DRIVER` / `ADMIN`) enforced in Spring Security.
- **Student**: register, login, manage profile, search rides, book/cancel,
  pay, rate driver, raise complaint.
- **Driver**: register (pending admin approval), register vehicle, create
  /edit/cancel rides, start/end ride, accept/reject bookings.
- **Admin**: dashboard stats (users, rides, revenue, complaints), verify
  students/drivers, block/unblock users, resolve complaints.
- **Dashboards**: role-specific dashboard UI for all three actors — this
  answers "can I create a dashboard profile with Spring Boot + REST API" —
  yes, `GET /api/admin/dashboard` (+ the equivalent student/driver views)
  power exactly that.

## Deliberately Not Included (see backend/README.md → "Not Yet Wired")

Live GPS tracking, real-time WebSocket chat, a real Razorpay integration,
the Python/ML ride-matching & recommendation modules, and Firebase push
notifications are extension points from the spec's "Future Scope" /
AI-heavy modules — they need separate services (Python, WebSocket broker,
payment gateway account) beyond a single Spring Boot REST backend.

## Making This a Real Git Repository

This folder is already `git init`'d locally with an initial commit (see
below). To push it to your own GitHub/GitLab:

```bash
cd CampusCommute
git remote add origin <your-empty-repo-url>
git branch -M main
git push -u origin main
```
